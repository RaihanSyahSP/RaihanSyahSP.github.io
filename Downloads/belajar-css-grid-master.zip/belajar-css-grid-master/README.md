# Belajar CSS GRID
### Code Repo untuk Playlist CSS GRID di channel youtube WebProgrammingUNPAS ::

[🔥 Link ke Playlist CSS GRID di YouTube 🔥](https://www.youtube.com/playlist?list=PLFIM0718LjIXmbwX0dEsoRVX-PC16vmuw)


Jangan lupa untuk subscribe channel youtube [WebProgrammingUNPAS](https://www.youtube.com/webprogrammingunpas) untuk mendapatkan tutorial Web Design dan Web Programming 😊🙏🏼

### Jika kalian ingin berdonasi untuk channel WebProgrammingUNPAS, bisa kunjungi link berikut :
[https://saweria.co/sandhikagalih](https://saweria.co/sandhikagalih)
<?php 
include 'lib/Alquran.php';
include 'lib/Sholat.php';
$AlQuran = new AlQuran;
$sholat  = new Sholat;
$ip = $sholat->get_client_ip();
$kota = $sholat->city($ip);
$jadwal = json_decode($sholat->jadwal($kota));
$listSurah = json_decode($AlQuran->surah());


?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Rendi Julianto">
    <meta name="generator" content="Hugo 0.80.0">
    <title>Al Qur'an</title>
    <meta name="theme-color" content="#7952b3">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/offcanvas/">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/offcanvas.css" rel="stylesheet">




    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
  </head>
  <body class="bg-light">
    


<main class="container">
  <div class="d-flex align-items-center p-3 my-3 text-white bg-purple rounded shadow-sm">
    <img class="me-3" src="https://lh3.googleusercontent.com/proxy/CJaJ8eOMMDrcfAXg20vfx2RqBmiJAIrboGVQrBssqPVNFgDNMKf7iSMwvII9PsF3i4Urd4FgNwVwd8yhycxnS2NeuK1KamBtjPQV8T8mgEPqy5CDna7L" alt="" width="48" height="38">
    <div class="lh-1">
    <h1 class="h6 mb-0 text-white lh-1">AlQuran Lite</h1>
      <small>Pukul : <?php echo date('Y-m-d - H:i:s')?></small>
    </div>
  </div>

  <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Jadwal Sholat | <?php echo $kota?> | <?php echo date('Y-m-d') ?></h6>
    <div class="d-flex text-muted pt-3">
      <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Imsak </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Imsak?></span>
        </div>
      </div>
    
    <div class="d-flex text-muted pt-3">
      <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Subuh </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Fajr?></span>
        </div>
      </div>
    
    <div class="d-flex text-muted pt-3">
    <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Dhuzur </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Dhuhr?></span>
        </div>
      </div>
    
    <div class="d-flex text-muted pt-3">
      <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Asyar </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Asr?></span>
        </div>
      </div>
    
    <div class="d-flex text-muted pt-3">
      <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Maghrib </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Maghrib?></span>
        </div>
      </div>
    
    <div class="d-flex text-muted pt-3">
      <img src="https://png.pngtree.com/element_our/png/20180922/muslim-prayer-icon-design-vector-png_107787.jpg" height="32px" width="32px" alt="">
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark">Isya </strong>
          </div>
          <span class="d-block"><?php echo $jadwal->results->datetime[0]->times->Isha?></span>
        </div>
      </div>
    


 
    <small class="d-block text-end mt-3">
      <a href="https://waktusholat.org/api/docs/day" target="_blank">API DOKUMENTASI JADWAL SHOLAT</a> 
      |
      <a href="https://api.quran.sutanlab.id/surah/" class="ml-5" target="_blank">API DOKUMENTASI AL QURAN</a>
    </small>
  </div>

  <div class="my-3 p-3 bg-body rounded shadow-sm">
    <h6 class="border-bottom pb-2 mb-0">Daftar Surah</h6>
<?php 
foreach($listSurah->data as $surah) {
?>
    <a href="/surah.php?id=<?php echo $surah->number?>" style="text-decoration: none;">
        <div class="d-flex text-muted pt-3">
           <img src="https://cdn3.iconfinder.com/data/icons/ramadan-30/129/3-512.png" style="margin-right:20px" width="32px" height="32px" alt="">
            <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
                <div class="d-flex justify-content-between">
                    <strong class="text-gray-dark"> <?php echo $surah->name->transliteration->id?> (<?php echo $surah->name->short?>) | Surah ke-<?php echo $surah->number ?></strong>
                    <p>Baca</p>
                </div>
                <span class="d-block"> Jumlah Ayat : <?php echo $surah->numberOfVerses?></span>
            </div>
        </div>
    </a>
<?php 
}?>
    

    <small class="d-block mt-3 text-center">
      <a href="https://www.facebook.com/rendyjul17" class="text-center text-muted" target="_blank">Rendi Julianto</a>
    </small>
  </div>
</main>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

      <script src="assets/js/offcanvas.js"></script>
  </body>
</html>

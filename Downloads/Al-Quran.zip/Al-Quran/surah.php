<?php 
include 'lib/Alquran.php';
$AlQuran = new AlQuran;
$id = 1;
if($_GET['id'] > 0 and $_GET['id'] < 115) {
    $id = $_GET['id'];
}
$surah = json_decode($AlQuran->surah($id));


?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Rendi Julianto">
    <meta name="generator" content="Hugo 0.80.0">
    <title>Al Qur'an</title>
    <meta name="theme-color" content="#7952b3">
    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/offcanvas/">
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/offcanvas.css" rel="stylesheet">




    <style>
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
    </style>

    
    <!-- Custom styles for this template -->
  </head>
  <body class="bg-light">
    


<main class="container">
  <div class="d-flex align-items-center p-3 my-3 text-white bg-purple rounded shadow-sm">
    <img class="me-3" src="https://lh3.googleusercontent.com/proxy/CJaJ8eOMMDrcfAXg20vfx2RqBmiJAIrboGVQrBssqPVNFgDNMKf7iSMwvII9PsF3i4Urd4FgNwVwd8yhycxnS2NeuK1KamBtjPQV8T8mgEPqy5CDna7L" alt="" width="48" height="38">
    <div class="lh-1">
      <h1 class="h6 mb-0 text-white lh-1">AlQuran Lite</h1>
      <small>Pukul : <?php echo date('Y-m-d - H:i:s')?></small>
    </div>
  </div>

  <div class="my-3 p-3 bg-body rounded shadow-sm">
  <div class="row">
      <div class="col-lg-2">
        <?php
            if($id > 1) {
        ?>
         <span class="btn btn-sm btn-primary text-start"><a href="/surah.php?id=<?php echo $id-1?>" style="text-decoration: none; color:white;">Kembali</a></span>
            <?php 
            }
        ?>
      </div>
      <div class="col-lg-8">
      <h6 class="border-bottom pb-2 mb-0 text-center">
            Surah <?php echo $surah->data->name->transliteration->id?> - <?php echo $surah->data->revelation->id ?> (<?php echo $surah->data->name->translation->id?>)
            </h6>
      </div>
      <div class="col-lg-2 text-end">
      <?php
            if($id < 114) {
        ?>
         <span class="btn btn-sm btn-success"><a href="/surah.php?id=<?php echo $id+1?>" style="text-decoration: none; color:white;">Lanjutkan</a></span>
            <?php 
            }
        ?>
      </div>
  </div>
<?php 
foreach($surah->data->verses as $detail) {
?>
    <div class="d-flex text-muted pt-3">  
        <div class="pb-3 mb-0 small lh-sm border-bottom w-100">
          <div class="d-flex justify-content-between">
            <strong class="text-gray-dark ml-4" style="font-size: large;"> <?php echo $detail->text->arab ?> </strong>
            <audio controls>
                <source src="<?php echo $detail->audio->primary?>" type="audio/ogg">
                Your browser does not support the audio element.
              </audio>
          </div>
          <span class="d-block">(<?php echo $detail->number->inSurah?>) <?php echo $detail->text->transliteration->en ?></span>
          <span class="d-block"><?php echo $detail->translation->id ?></span>
        </div>
      </div>
      
<?php } ?>

    <small class="d-block mt-3 text-center">
      <a href="https://www.facebook.com/rendyjul17" class="text-center text-muted" target="_blank">Rendi Julianto</a>
    </small>
  </div>


</main>


    <script src="assets/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/offcanvas.js"></script>
  </body>
</html>
